package com.electro.notebook;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.widget.ImageView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

final class Media {
    private Media() {}

    static String saveImage(Context c, Uri uri) throws IOException {
        File directory = new File(c.getFilesDir(), "images");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Unable to create photo directory");
        File output = new File(directory, UUID.randomUUID().toString() + ".jpg");
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(output)) {
            if (in == null) throw new IOException("Unable to read image");
            byte[] buffer = new byte[32768];
            int n;
            long copied = 0;
            while ((n = in.read(buffer)) != -1) {
                copied += n;
                if (copied > 35L * 1024 * 1024) throw new IOException("الصورة أكبر من 35 ميغابايت");
                out.write(buffer, 0, n);
            }
        } catch (IOException err) {
            //noinspection ResultOfMethodCallIgnored
            output.delete();
            throw err;
        }
        return output.getAbsolutePath();
    }

    static void display(ImageView image, String path, int limitPx) {
        if (path == null || path.isEmpty() || !new File(path).isFile()) return;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = 1;
        while (bounds.outWidth / opt.inSampleSize > limitPx * 2 || bounds.outHeight / opt.inSampleSize > limitPx * 2) {
            opt.inSampleSize *= 2;
        }
        Bitmap bmp = BitmapFactory.decodeFile(path, opt);
        if (bmp == null) return;
        try {
            ExifInterface exif = new ExifInterface(path);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int deg = orientation == ExifInterface.ORIENTATION_ROTATE_90 ? 90 :
                    orientation == ExifInterface.ORIENTATION_ROTATE_180 ? 180 :
                    orientation == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
            if (deg != 0) {
                Matrix matrix = new Matrix();
                matrix.postRotate(deg);
                Bitmap rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true);
                if (rotated != bmp) bmp.recycle();
                bmp = rotated;
            }
        } catch (IOException ignored) {}
        image.setImageBitmap(bmp);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
    }

    static void removeStoredImage(Context c, String path) {
        if (path == null || path.isEmpty()) return;
        File image = new File(path);
        File allowed = new File(c.getFilesDir(), "images");
        File imported = new File(c.getFilesDir(), "imported_media");
        boolean ownSavedPhoto = image.getParentFile() != null && image.getParentFile().equals(allowed);
        boolean importedPhoto = isInside(image, imported) && image.getName().endsWith("_image");
        if (ownSavedPhoto || importedPhoto) {
            //noinspection ResultOfMethodCallIgnored
            image.delete();
        }
    }

    static void removeStoredVideo(Context c, String uriText) {
        if (uriText == null || uriText.isEmpty()) return;
        Uri uri = Uri.parse(uriText);
        if (!"file".equals(uri.getScheme()) || uri.getPath() == null) return;
        File video = new File(uri.getPath());
        if (video.getName().endsWith("_video") && isInside(video, new File(c.getFilesDir(), "imported_media"))) {
            //noinspection ResultOfMethodCallIgnored
            video.delete();
        }
    }

    private static boolean isInside(File file, File parent) {
        try {
            String parentPath = parent.getCanonicalPath() + File.separator;
            return file.getCanonicalPath().startsWith(parentPath);
        } catch (IOException ignored) { return false; }
    }
}
