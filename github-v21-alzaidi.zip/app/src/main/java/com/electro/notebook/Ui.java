package com.electro.notebook;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(7, 17, 30);
    static final int CARD = Color.rgb(17, 34, 52);
    static final int CARD_LIGHT = Color.rgb(23, 45, 65);
    static final int TEXT = Color.rgb(243, 249, 252);
    static final int MUTED = Color.rgb(163, 187, 198);
    static final int ACCENT = Color.rgb(72, 214, 195);
    static final int BORDER = Color.rgb(46, 71, 87);

    private Ui() {}

    static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static void setup(Activity activity) {
        Window window = activity.getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    static GradientDrawable shape(int color, float radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable outline(int color, int border, float radiusDp, Context c) {
        GradientDrawable d = shape(color, radiusDp, c);
        d.setStroke(dp(c, 1), border);
        return d;
    }

    static TextView text(Context c, String str, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(str);
        t.setTextColor(color);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    static TextView pill(Context c, String str, int color) {
        TextView t = text(c, str, 13, color, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(shape(CARD_LIGHT, 14, c));
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        return t;
    }

    static Button button(Context c, String str, boolean primary) {
        Button b = new Button(c);
        b.setText(str);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? BG : TEXT);
        b.setBackground(primary ? shape(ACCENT, 15, c) : outline(CARD_LIGHT, BORDER, 15, c));
        b.setMinHeight(dp(c, 52));
        b.setPadding(dp(c, 15), dp(c, 8), dp(c, 15), dp(c, 8));
        return b;
    }

    static EditText input(Context c, String hint, boolean multiline) {
        EditText e = new EditText(c);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setTextSize(15);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        e.setSingleLine(!multiline);
        if (multiline) {
            e.setMinLines(5);
            e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        } else {
            e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        e.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        e.setBackground(outline(CARD, BORDER, 15, c));
        return e;
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    static void pad(View v, Context c, int horizontal, int vertical) {
        v.setPadding(dp(c,horizontal), dp(c,vertical), dp(c,horizontal), dp(c,vertical));
    }

    static LinearLayout.LayoutParams lp(Context c, int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(c,w), h < 0 ? h : dp(c,h));
        p.topMargin = dp(c, top);
        p.bottomMargin = dp(c, bottom);
        return p;
    }

    static LinearLayout.LayoutParams weight(Context c) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
    }

    static ScrollView scroll(Context c) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setClipToPadding(false);
        s.setVerticalScrollBarEnabled(false);
        return s;
    }

    static TextView back(Activity a) {
        TextView back = pill(a, "‹  رجوع", ACCENT);
        back.setOnClickListener(v -> a.finish());
        return back;
    }
}
