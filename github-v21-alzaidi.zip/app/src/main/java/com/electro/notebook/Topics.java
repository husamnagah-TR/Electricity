package com.electro.notebook;

final class Topics {
    static final String[] NAMES = {
        "فولت", "أمبير", "إلكترون", "مجال كهربائي", "مجال مغناطيسي"
    };
    static final String[] SYMBOLS = {"V", "A", "e⁻", "E", "B"};
    static final String[] DESCRIPTIONS = {
        "الجهد الكهربائي وفروق الجهد",
        "التيار الكهربائي وطرق القياس",
        "الإلكترونات والشحنات الكهربائية",
        "شدة المجال والقوة والجهد",
        "الفيض المغناطيسي والحث والقوى"
    };
    static final int[] COLORS = {0xFF55D7F6, 0xFFFFCB75, 0xFFB9A8FF, 0xFF6EE4B1, 0xFFFF9E9C};

    static int safeIndex(int i) { return (i >= 0 && i < NAMES.length) ? i : 0; }
    private Topics() {}
}
