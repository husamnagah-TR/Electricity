package com.electro.notebook;

import java.util.ArrayList;
import java.util.List;

final class Note {
    long id;
    int topic;
    String title = "";
    String body = "";
    String imagePath = ""; // legacy primary photo
    final List<String> imagePaths = new ArrayList<>();
    String videoUrl = "";
    String videoUri = "";
    long updatedAt;
    boolean pinned;

    List<String> pictures() {
        List<String> paths = new ArrayList<>(imagePaths);
        if (paths.isEmpty() && imagePath != null && !imagePath.isEmpty()) paths.add(imagePath);
        return paths;
    }
    boolean hasImage() { return !pictures().isEmpty(); }
    boolean hasVideo() { return (videoUrl != null && !videoUrl.isEmpty()) || (videoUri != null && !videoUri.isEmpty()); }
    boolean hasText() { return body != null && !body.trim().isEmpty(); }
}
