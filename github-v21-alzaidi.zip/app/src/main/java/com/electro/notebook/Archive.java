package com.electro.notebook;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Portable, explicit backup of all notes and their media; adds notes on restore. */
final class Archive {
    private static final long MAX_RESTORE_BYTES = 2L * 1024 * 1024 * 1024;
    private static final int MAX_NOTES = 20000;
    private Archive() {}

    static int exportTo(Context context, Uri destination) throws Exception {
        List<Note> notes;
        try (Database db = new Database(context)) { notes = db.allNotes(); }
        JSONArray data = new JSONArray();
        try (OutputStream output = context.getContentResolver().openOutputStream(destination, "wt")) {
            if (output == null) throw new IOException("لا يمكن الكتابة إلى الملف المحدد");
            try (ZipOutputStream zip = new ZipOutputStream(output)) {
                byte[] buffer = new byte[65536];
                for (Note n : notes) {
                    JSONObject record = new JSONObject();
                    record.put("topic", n.topic);
                    record.put("title", n.title);
                    record.put("body", n.body);
                    record.put("videoUrl", n.videoUrl);
                    record.put("updatedAt", n.updatedAt);
                    record.put("pinned", n.pinned);
                    if (n.hasImage()) {
                        JSONArray photoNames = new JSONArray();
                        int imageIndex = 0;
                        for (String path : n.pictures()) {
                            File image = new File(path);
                            if (!image.isFile()) throw new IOException("الصورة مفقودة في: " + n.title);
                            String name = "assets/" + n.id + "_image_" + imageIndex++;
                            try (InputStream in = new FileInputStream(image)) { addFile(zip, in, name, buffer); }
                            photoNames.put(name);
                        }
                        record.put("imageEntries", photoNames);
                    }
                    if (n.videoUri != null && !n.videoUri.isEmpty()) {
                        String name = "assets/" + n.id + "_video";
                        try (InputStream in = openMedia(context, n.videoUri)) {
                            if (in == null) throw new IOException("الفيديو غير متاح: " + n.title);
                            addFile(zip, in, name, buffer);
                        } catch (Exception ex) {
                            throw new IOException("تعذر تضمين الفيديو الخاص بالملاحظة «" + n.title + "»: " + ex.getMessage(), ex);
                        }
                        record.put("videoEntry", name);
                    }
                    data.put(record);
                }
                JSONObject manifest = new JSONObject();
                manifest.put("format", "electric-notebook-backup");
                manifest.put("version", 2);
                manifest.put("notes", data);
                byte[] bytes = manifest.toString().getBytes(StandardCharsets.UTF_8);
                zip.putNextEntry(new ZipEntry("notes.json"));
                zip.write(bytes);
                zip.closeEntry();
                zip.finish();
            }
        }
        return notes.size();
    }

    private static void addFile(ZipOutputStream zip, InputStream in, String name, byte[] buffer) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        int n;
        while ((n = in.read(buffer)) != -1) zip.write(buffer, 0, n);
        zip.closeEntry();
    }

    private static InputStream openMedia(Context context, String uriText) throws IOException {
        Uri uri = Uri.parse(uriText);
        if ("file".equals(uri.getScheme())) {
            String path = uri.getPath();
            if (path == null) throw new IOException("مسار الفيديو غير صالح");
            return new FileInputStream(new File(path));
        }
        if ("content".equals(uri.getScheme())) return context.getContentResolver().openInputStream(uri);
        throw new IOException("صيغة رابط الفيديو المحلي غير مدعومة");
    }

    static int importFrom(Context context, Uri source) throws Exception {
        File stage = new File(context.getFilesDir(), "imported_media/" + UUID.randomUUID());
        if (!stage.mkdirs()) throw new IOException("لا يمكن إعداد مساحة للاستعادة");
        boolean committed = false;
        try {
            byte[] manifestBytes = null;
            Set<String> extracted = new HashSet<>();
            long totalBytes = 0;
            int entries = 0;
            try (InputStream input = context.getContentResolver().openInputStream(source)) {
                if (input == null) throw new IOException("تعذر قراءة النسخة الاحتياطية");
                try (ZipInputStream zip = new ZipInputStream(input)) {
                    ZipEntry item;
                    byte[] buffer = new byte[65536];
                    while ((item = zip.getNextEntry()) != null) {
                        if (item.isDirectory()) { zip.closeEntry(); continue; }
                        if (++entries > MAX_NOTES * 14 + 1) throw new IOException("ملف النسخة يحتوي عناصر أكثر من المسموح");
                        String name = item.getName();
                        boolean isManifest = "notes.json".equals(name);
                        if (!isManifest && !name.matches("assets/[0-9]+_(image(?:_[0-9]+)?|video)")) {
                            throw new IOException("ملف غير متوقع داخل النسخة الاحتياطية");
                        }
                        if (!extracted.add(name)) throw new IOException("تكرار ملفات داخل النسخة الاحتياطية");
                        OutputStream out;
                        File target = null;
                        if (isManifest) {
                            out = new ByteArrayOutputStream();
                        } else {
                            target = new File(stage, name.substring("assets/".length()));
                            out = new FileOutputStream(target);
                        }
                        try (OutputStream sink = out) {
                            int count;
                            while ((count = zip.read(buffer)) != -1) {
                                totalBytes += count;
                                if (totalBytes > MAX_RESTORE_BYTES) throw new IOException("حجم النسخة يتجاوز الحد المسموح (2 غيغابايت)");
                                if (isManifest && ((ByteArrayOutputStream)sink).size() + count > 12 * 1024 * 1024) {
                                    throw new IOException("قائمة الملاحظات كبيرة جدًا");
                                }
                                sink.write(buffer, 0, count);
                            }
                        }
                        if (isManifest) manifestBytes = ((ByteArrayOutputStream)out).toByteArray();
                        zip.closeEntry();
                    }
                }
            }
            if (manifestBytes == null) throw new IOException("ملف notes.json غير موجود في النسخة");
            JSONObject manifest = new JSONObject(new String(manifestBytes, StandardCharsets.UTF_8));
            if (!"electric-notebook-backup".equals(manifest.optString("format")) || (manifest.optInt("version") != 1 && manifest.optInt("version") != 2)) {
                throw new IOException("هذه ليست نسخة احتياطية متوافقة مع دفتر الكهرباء");
            }
            JSONArray array = manifest.getJSONArray("notes");
            if (array.length() > MAX_NOTES) throw new IOException("عدد الملاحظات كبير جدًا");
            List<Note> imported = new ArrayList<>();
            for (int i=0;i<array.length();i++) {
                JSONObject r = array.getJSONObject(i);
                int topic = r.getInt("topic");
                if (topic < 0 || topic >= Topics.NAMES.length) throw new IOException("قسم غير معروف في ملف النسخة");
                Note note = new Note();
                note.topic = topic;
                note.title = r.getString("title");
                note.body = r.optString("body", "");
                note.videoUrl = r.optString("videoUrl", "");
                note.updatedAt = r.optLong("updatedAt", System.currentTimeMillis());
                note.pinned = r.optBoolean("pinned", false);
                JSONArray photoEntries = r.optJSONArray("imageEntries");
                if (photoEntries != null) {
                    if (photoEntries.length() > 12) throw new IOException("عدد صور الملاحظة يتجاوز الحد المسموح");
                    for (int photo=0;photo<photoEntries.length();photo++) {
                        String image = resolveAsset(stage, extracted, photoEntries.getString(photo), false);
                        if (!image.isEmpty()) note.imagePaths.add(image);
                    }
                } else {
                    String oldImage = resolveAsset(stage, extracted, r.optString("imageEntry", ""), false);
                    if (!oldImage.isEmpty()) note.imagePaths.add(oldImage);
                }
                note.imagePath = note.imagePaths.isEmpty() ? "" : note.imagePaths.get(0);
                String localVideo = resolveAsset(stage, extracted, r.optString("videoEntry", ""), true);
                note.videoUri = localVideo.isEmpty() ? "" : Uri.fromFile(new File(localVideo)).toString();
                imported.add(note);
            }
            // SQLite transaction: all imported notes are inserted, or none are.
            try (Database db = new Database(context)) { db.insertImported(imported); }
            committed = true;
            return imported.size();
        } finally {
            if (!committed) removeTree(stage);
        }
    }

    private static String resolveAsset(File stage, Set<String> extracted, String entry, boolean video) throws IOException {
        if (entry.isEmpty()) return "";
        if (!entry.matches("assets/[0-9]+_(image(?:_[0-9]+)?|video)")) throw new IOException("اسم وسيط غير صالح");
        if (video ? !entry.endsWith("_video") : !entry.matches("assets/[0-9]+_image(?:_[0-9]+)?")) throw new IOException("نوع ملف الوسائط غير متوافق");
        if (!extracted.contains(entry)) throw new IOException("وسيط مفقود داخل النسخة: " + entry);
        File file = new File(stage, entry.substring("assets/".length()));
        if (!file.isFile()) throw new IOException("ملف وسائط غير موجود");
        return file.getAbsolutePath();
    }

    private static void removeTree(File path) {
        if (path.isDirectory()) {
            File[] children = path.listFiles();
            if (children != null) for (File child : children) removeTree(child);
        }
        //noinspection ResultOfMethodCallIgnored
        path.delete();
    }
}
