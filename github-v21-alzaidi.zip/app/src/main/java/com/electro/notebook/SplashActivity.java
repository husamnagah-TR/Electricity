package com.electro.notebook;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A small, self-contained animated brand intro; no internet or extra permissions required. */
public final class SplashActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goHome = this::openHome;
    private ValueAnimator boltAnimation;
    private AnimatorSet textAnimations;
    private boolean hasNavigated;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.setup(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        root.addView(new Atmosphere(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout center = Ui.column(this);
        center.setGravity(Gravity.CENTER);
        center.setPadding(Ui.dp(this, 24), 0, Ui.dp(this, 24), 0);
        FrameLayout.LayoutParams centerParams = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        root.addView(center, centerParams);

        ElectricMark icon = new ElectricMark(this);
        LinearLayout.LayoutParams markParams = new LinearLayout.LayoutParams(-1, Ui.dp(this, 142));
        markParams.bottomMargin = Ui.dp(this, 10);
        center.addView(icon, markParams);

        TextView name = Ui.text(this, "الزايدي", 46, Ui.TEXT, true);
        name.setGravity(Gravity.CENTER);
        center.addView(name, new LinearLayout.LayoutParams(-1, -2));

        View underline = new View(this);
        underline.setBackgroundColor(Ui.ACCENT);
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 2));
        lineParams.gravity = Gravity.CENTER_HORIZONTAL;
        lineParams.topMargin = Ui.dp(this, 18);
        lineParams.bottomMargin = Ui.dp(this, 16);
        center.addView(underline, lineParams);

        TextView subtitle = Ui.text(this, "دفتر الكهرباء", 19, Ui.MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        center.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        TextView tagline = Ui.text(this, "مساحتك للعلم والمعرفة", 12, Ui.MUTED, false);
        tagline.setGravity(Gravity.CENTER);
        center.addView(tagline, Ui.lp(this, -1, -2, 10, 0));

        root.setContentDescription("الزايدي، دفتر الكهرباء");
        root.setOnClickListener(view -> openHome()); // Tap to skip the animation.
        setContentView(root);

        // Respect Android's reduced/disabled animation setting.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !ValueAnimator.areAnimatorsEnabled()) {
            handler.postDelayed(goHome, 250);
            return;
        }

        name.setAlpha(0f);
        name.setTranslationY(Ui.dp(this, 18));
        name.setScaleX(0.96f);
        name.setScaleY(0.96f);
        underline.setScaleX(0f);
        subtitle.setAlpha(0f);
        subtitle.setTranslationY(Ui.dp(this, 12));
        tagline.setAlpha(0f);

        boltAnimation = ValueAnimator.ofFloat(0f, 1f);
        boltAnimation.setStartDelay(100);
        boltAnimation.setDuration(990);
        boltAnimation.addUpdateListener(animation -> icon.setProgress((Float) animation.getAnimatedValue()));
        boltAnimation.start();

        textAnimations = new AnimatorSet();
        textAnimations.playTogether(
                fade(name, 0f, 1f, 590, 510),
                slide(name, Ui.dp(this, 18), 0f, 590, 510),
                scale(name, View.SCALE_X, 0.96f, 1f, 590, 510),
                scale(name, View.SCALE_Y, 0.96f, 1f, 590, 510),
                scale(underline, View.SCALE_X, 0f, 1f, 930, 330),
                fade(subtitle, 0f, 1f, 1040, 450),
                slide(subtitle, Ui.dp(this, 12), 0f, 1040, 450),
                fade(tagline, 0f, 1f, 1320, 450)
        );
        textAnimations.start();
        handler.postDelayed(goHome, 2300);
    }

    private ObjectAnimator fade(View view, float from, float to, long delay, long duration) {
        return animate(view, View.ALPHA, from, to, delay, duration);
    }

    private ObjectAnimator slide(View view, float from, float to, long delay, long duration) {
        return animate(view, View.TRANSLATION_Y, from, to, delay, duration);
    }

    private ObjectAnimator scale(View view, android.util.Property<View, Float> property,
                                 float from, float to, long delay, long duration) {
        return animate(view, property, from, to, delay, duration);
    }

    private ObjectAnimator animate(View view, android.util.Property<View, Float> property,
                                   float from, float to, long delay, long duration) {
        ObjectAnimator a = ObjectAnimator.ofFloat(view, property, from, to);
        a.setStartDelay(delay);
        a.setDuration(duration);
        return a;
    }

    private void openHome() {
        if (hasNavigated || isFinishing()) return;
        hasNavigated = true;
        handler.removeCallbacks(goHome);
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(goHome);
        if (boltAnimation != null) boltAnimation.cancel();
        if (textAnimations != null) textAnimations.cancel();
        super.onDestroy();
    }

    /** Soft vignette with a teal halo instead of a heavy background image. */
    private static final class Atmosphere extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Atmosphere(Activity a) { super(a); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() * 0.46f;
            float radius = Math.max(getWidth(), getHeight()) * 0.60f;
            paint.setShader(new RadialGradient(cx, cy, radius,
                    new int[]{Color.rgb(19, 45, 62), Ui.BG}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0f, 0f, getWidth(), getHeight(), paint);
            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            paint.setColor(Color.argb(17, 72, 214, 195));
            for (int i = 0; i < 3; i++) {
                canvas.drawCircle(cx, cy, Ui.dp(getContext(), 130 + i * 55), paint);
            }
            paint.setStyle(Paint.Style.FILL);
        }
    }

    /** Vector lightning symbol that draws itself; no remote assets or image files. */
    private static final class ElectricMark extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path bolt = new Path();
        private final Path visibleBolt = new Path();
        private final PathMeasure measure;
        private float progress;

        ElectricMark(Activity a) {
            super(a);
            bolt.moveTo(66, 8);
            bolt.lineTo(34, 67);
            bolt.lineTo(60, 67);
            bolt.lineTo(45, 121);
            bolt.lineTo(99, 51);
            bolt.lineTo(73, 51);
            bolt.lineTo(87, 8);
            bolt.close();
            measure = new PathMeasure(bolt, false);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null); // Allows the small neon glow shadow.
            setContentDescription("شعار برق الزايدي");
        }

        void setProgress(float p) {
            progress = Math.max(0, Math.min(1, p));
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float size = Math.min(getWidth(), getHeight()) * 0.86f;
            canvas.save();
            canvas.translate((getWidth() - size) / 2f, (getHeight() - size) / 2f);
            canvas.scale(size / 130f, size / 130f);

            paint.reset();
            paint.setAntiAlias(true);
            paint.setColor(Color.argb(55, 72, 214, 195));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.2f);
            canvas.drawCircle(66, 65, 61, paint);

            visibleBolt.reset();
            measure.getSegment(0f, measure.getLength() * progress, visibleBolt, true);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(5f);
            paint.setShader(new LinearGradient(40, 15, 95, 111,
                    Color.rgb(120, 230, 239), Color.rgb(72, 214, 195), Shader.TileMode.CLAMP));
            paint.setShadowLayer(14f, 0f, 0f, Color.argb(185, 72, 214, 195));
            canvas.drawPath(visibleBolt, paint);
            paint.clearShadowLayer();
            paint.setShader(null);

            if (progress > 0.76f) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.argb((int)(205 * Math.min(1f, (progress - 0.76f) / 0.24f)),
                        72, 214, 195));
                canvas.drawPath(bolt, paint);
            }

            float sparkAlpha = Math.min(1f, progress * 1.8f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb((int)(210f * sparkAlpha), 162, 236, 239));
            canvas.drawCircle(18f, 38f, 2.3f, paint);
            canvas.drawCircle(109f, 86f, 1.8f, paint);
            canvas.drawCircle(105f, 25f, 1.5f, paint);
            canvas.restore();
        }
    }
}
