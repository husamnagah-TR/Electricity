package com.electro.notebook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class BackupActivity extends Activity {
    private static final int EXPORT = 981;
    private static final int IMPORT = 982;
    private TextView status;
    private Button exportButton, importButton;
    private boolean busy;

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        Ui.setup(this);
        ScrollView scroll = Ui.scroll(this);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout content = Ui.column(this);
        Ui.pad(content,this,20,22);
        scroll.addView(content);
        content.addView(Ui.back(this),Ui.lp(this,-2,-2,0,18));
        content.addView(Ui.text(this,"النسخ الاحتياطي والاستعادة",25,Ui.TEXT,true),Ui.lp(this,-1,-2,0,10));
        content.addView(Ui.text(this,"احفظ نسخة من نصوصك وصورك وفيديوهاتك المحلية وروابط الفيديو في ملف ZIP. يمكنك نقل الملف إلى جهاز آخر.",15,Ui.MUTED,false),Ui.lp(this,-1,-2,0,18));
        exportButton = Ui.button(this,"⇪  إنشاء نسخة احتياطية",true);
        content.addView(exportButton,Ui.lp(this,-1,-2,0,14));
        importButton = Ui.button(this,"⇩  استعادة من ملف ZIP",false);
        content.addView(importButton,Ui.lp(this,-1,-2,0,18));
        status = Ui.text(this,"جاهز",14,Ui.ACCENT,true);
        content.addView(status,Ui.lp(this,-1,-2,0,18));
        content.addView(Ui.text(this,"مهم: الاستعادة تضيف الملاحظات ولا تمسح الملاحظات الموجودة؛ إعادة استيراد الملف نفسه ستكررها. قد يصبح ملف النسخ كبيرًا عند تضمين الفيديوهات. يُفضّل اختيار مساحة تخزين آمنة خارج الهاتف.",14,Ui.MUTED,false));
        exportButton.setOnClickListener(v -> chooseExport());
        importButton.setOnClickListener(v -> chooseImport());
        setContentView(scroll);
    }

    private void chooseExport() {
        if (busy) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        String date = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE,"electricity-backup-"+date+".zip");
        startActivityForResult(intent,EXPORT);
    }

    private void chooseImport() {
        if (busy) return;
        new AlertDialog.Builder(this)
                .setTitle("استعادة الملاحظات")
                .setMessage("سيتم إضافة الملاحظات الموجودة في ملف النسخة الاحتياطية إلى التطبيق دون حذف الملاحظات الحالية. هل تريد المتابعة؟")
                .setNegativeButton("إلغاء",(dialog,which)->{})
                .setPositiveButton("اختيار ملف",(dialog,which)->{
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/zip");
                    startActivityForResult(intent,IMPORT);
                }).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode!=RESULT_OK || data==null || data.getData()==null || busy) return;
        if (requestCode!=EXPORT && requestCode!=IMPORT) return;
        Uri uri = data.getData();
        busy = true;
        exportButton.setEnabled(false);
        importButton.setEnabled(false);
        boolean exporting = requestCode==EXPORT;
        status.setText(exporting ? "جارٍ إنشاء النسخة... لا تغلق التطبيق" : "جارٍ استعادة البيانات... لا تغلق التطبيق");
        new Thread(() -> {
            try {
                int num = exporting ? Archive.exportTo(getApplicationContext(),uri) : Archive.importFrom(getApplicationContext(),uri);
                runOnUiThread(() -> complete((exporting ? "تم تصدير " : "تم استعادة ") + num + " ملاحظة بنجاح"));
            } catch (Exception e) {
                runOnUiThread(() -> complete("تعذرت العملية: " + e.getMessage()));
            }
        }, "notes-backup").start();
    }

    private void complete(String message) {
        busy = false;
        exportButton.setEnabled(true);
        importButton.setEnabled(true);
        status.setText(message);
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }
}
