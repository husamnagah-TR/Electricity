package com.electro.notebook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

public final class SearchActivity extends Activity {
    private EditText input;
    private LinearLayout results;
    private TextView count;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable change = this::reload;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.setup(this);
        ScrollView scroll=Ui.scroll(this);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout content=Ui.column(this);
        Ui.pad(content,this,20,22);
        scroll.addView(content);
        content.addView(Ui.back(this),Ui.lp(this,-2,-2,0,18));
        content.addView(Ui.text(this,"البحث في كل الأقسام",25,Ui.TEXT,true),Ui.lp(this,-1,-2,0,15));
        input=Ui.input(this,"ابحث عن قانون أو مفهوم أو معلومة...",false);
        content.addView(input,Ui.lp(this,-1,-2,0,15));
        count=Ui.text(this,"اكتب كلمة لتظهر النتائج",14,Ui.MUTED,false);
        content.addView(count,Ui.lp(this,-1,-2,0,15));
        results=Ui.column(this);
        content.addView(results);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int c,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                handler.removeCallbacks(change);
                handler.postDelayed(change,200);
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        setContentView(scroll);
    }

    @Override protected void onResume() { super.onResume(); if (results!=null) reload(); }
    @Override protected void onDestroy() { handler.removeCallbacks(change); super.onDestroy(); }

    private void reload() {
        if (results == null) return;
        results.removeAllViews();
        String query = input.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) { count.setText("اكتب كلمة لتظهر النتائج"); return; }
        int shown=0;
        List<Note> list;
        try (Database db=new Database(this)) { list=db.allNotes(); }
        for (Note note:list) {
            if (!(note.title + " " + note.body).toLowerCase(Locale.ROOT).contains(query)) continue;
            LinearLayout card=Ui.column(this);
            card.setBackground(Ui.outline(Ui.CARD,Ui.BORDER,16,this));
            Ui.pad(card,this,16,14);
            card.addView(Ui.text(this,Topics.NAMES[note.topic],12,Topics.COLORS[note.topic],true));
            card.addView(Ui.text(this,(note.pinned ? "★  " : "") + note.title,18,Ui.TEXT,true),Ui.lp(this,-1,-2,4,6));
            if (note.hasText()) {
                TextView preview=Ui.text(this,note.body,13,Ui.MUTED,false);
                preview.setMaxLines(2);
                card.addView(preview);
            }
            card.setOnClickListener(v -> {
                Intent intent=new Intent(this,DetailActivity.class);
                intent.putExtra("id",note.id);
                startActivity(intent);
            });
            results.addView(card,Ui.lp(this,-1,-2,0,10));
            shown++;
        }
        count.setText(shown + " نتيجة");
        if (shown==0) results.addView(Ui.text(this,"لم يتم العثور على نتائج",16,Ui.MUTED,false));
    }
}
