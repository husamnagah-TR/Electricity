package com.electro.notebook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class DetailActivity extends Activity {
    private long noteId;
    private LinearLayout container;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.setup(this);
        noteId = getIntent().getLongExtra("id",0);
        ScrollView scroll=Ui.scroll(this);
        scroll.setBackgroundColor(Ui.BG);
        container=Ui.column(this);
        Ui.pad(container,this,21,23);
        scroll.addView(container);
        setContentView(scroll);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        if (container==null) return;
        Note note;
        try (Database db = new Database(this)) { note=db.get(noteId); }
        if (note == null) { finish(); return; }
        container.removeAllViews();
        container.addView(Ui.back(this),Ui.lp(this,-2,-2,0,23));
        container.addView(Ui.text(this,"◉  "+Topics.NAMES[note.topic],14,Topics.COLORS[note.topic],true),Ui.lp(this,-1,-2,0,8));
        container.addView(Ui.text(this,note.title,28,Ui.TEXT,true),Ui.lp(this,-1,-2,0,20));

        if (note.hasText()) {
            LinearLayout block=Ui.column(this);
            block.setBackground(Ui.outline(Ui.CARD,Ui.BORDER,18,this));
            Ui.pad(block,this,17,20);
            block.addView(Ui.text(this,"الملاحظات",14,Ui.ACCENT,true),Ui.lp(this,-1,-2,0,13));
            TextView body=Ui.text(this,note.body,17,Ui.TEXT,false);
            body.setLineSpacing(Ui.dp(this,5),1f);
            body.setTextIsSelectable(true);
            block.addView(body);
            container.addView(block,Ui.lp(this,-1,-2,0,19));
        }

        if (note.hasImage()) {
            container.addView(Ui.text(this,"الصور المرفقة (" + note.pictures().size() + ")",18,Ui.TEXT,true),Ui.lp(this,-1,-2,0,10));
            for (String path : note.pictures()) {
                ImageView image = new ImageView(this);
                image.setBackground(Ui.shape(Ui.CARD,16,this));
                Media.display(image,path,550);
                container.addView(image,Ui.lp(this,-1,250,0,9));
                image.setOnClickListener(v -> showImage(path));
            }
            container.addView(Ui.text(this,"اضغط على أي صورة لعرضها بحجم أكبر",12,Ui.MUTED,false),Ui.lp(this,-1,-2,0,19));
        }

        if (note.videoUrl != null && !note.videoUrl.isEmpty()) {
            container.addView(Ui.text(this,"فيديو عبر الإنترنت",18,Ui.TEXT,true),Ui.lp(this,-1,-2,0,8));
            TextView source=Ui.text(this,note.videoUrl,12,Ui.MUTED,false);
            source.setTextIsSelectable(true);
            container.addView(source,Ui.lp(this,-1,-2,0,10));
            android.widget.Button open=Ui.button(this,"▷  مشاهدة الفيديو داخل التطبيق",true);
            container.addView(open,Ui.lp(this,-1,-2,0,20));
            open.setOnClickListener(v -> {
                Intent i=new Intent(this,PlayerActivity.class);
                i.putExtra("url",note.videoUrl);
                startActivity(i);
            });
        }
        if (note.videoUri != null && !note.videoUri.isEmpty()) {
            container.addView(Ui.text(this,"فيديو محفوظ على الهاتف",18,Ui.TEXT,true),Ui.lp(this,-1,-2,0,10));
            android.widget.Button local=Ui.button(this,"▷  تشغيل الفيديو المرفق",true);
            container.addView(local,Ui.lp(this,-1,-2,0,20));
            local.setOnClickListener(v -> {
                Intent i=new Intent(this,PlayerActivity.class);
                i.putExtra("video_uri",note.videoUri);
                startActivity(i);
            });
        }

        LinearLayout actions=Ui.row(this);
        android.widget.Button edit=Ui.button(this,"✎  تعديل",false);
        actions.addView(edit,Ui.weight(this));
        android.widget.Button del=Ui.button(this,"حذف",false);
        LinearLayout.LayoutParams deleteParams=Ui.weight(this);
        deleteParams.rightMargin=Ui.dp(this,8);
        actions.addView(del,deleteParams);
        container.addView(actions,Ui.lp(this,-1,-2,15,12));
        android.widget.Button pin = Ui.button(this, note.pinned ? "★ إزالة من الملاحظات المثبتة" : "☆ تثبيت هذه الملاحظة", false);
        container.addView(pin, Ui.lp(this,-1,-2,0,20));
        pin.setOnClickListener(v -> {
            try (Database db = new Database(this)) { db.togglePinned(note.id, !note.pinned); }
            refresh();
        });
        edit.setOnClickListener(v -> {
            Intent i=new Intent(this,EditorActivity.class);
            i.putExtra("id",note.id);
            startActivity(i);
        });
        del.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("حذف الملاحظة؟")
            .setMessage("سيتم حذف الملاحظة وصورها المرفقة نهائيًا من التطبيق.")
            .setNegativeButton("إلغاء",(d,w)->{})
            .setPositiveButton("حذف",(d,w)->{
                try (Database db=new Database(this)) { db.delete(note.id); }
                for (String path : note.pictures()) Media.removeStoredImage(this,path);
                Media.removeStoredVideo(this,note.videoUri);
                finish();
            }).show());
    }

    private void showImage(String path) {
        ImageView image=new ImageView(this);
        image.setAdjustViewBounds(true);
        image.setPadding(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));
        Media.display(image,path,1900);
        new AlertDialog.Builder(this).setView(image).setPositiveButton("إغلاق",(d,w)->{}).show();
    }
}
