package com.electro.notebook;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public final class PlayerActivity extends Activity {
    private WebView browser;
    private VideoView localPlayer;
    private FrameLayout root;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback customCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.setup(this);
        String videoUrl = getIntent().getStringExtra("url");
        String videoUri = getIntent().getStringExtra("video_uri");
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        LinearLayout base = Ui.column(this);
        root.addView(base, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = Ui.row(this);
        Ui.pad(top,this,15,12);
        TextView back = Ui.back(this);
        top.addView(back);
        TextView heading=Ui.text(this,"مشاهدة الفيديو",17,Ui.TEXT,true);
        heading.setGravity(Gravity.CENTER);
        top.addView(heading,Ui.weight(this));
        if (videoUrl != null && !videoUrl.isEmpty()) {
            TextView external = Ui.pill(this,"فتح خارجي ↗",Ui.ACCENT);
            top.addView(external);
            external.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(videoUrl)));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(this,"لا يوجد متصفح يمكنه فتح الفيديو",Toast.LENGTH_LONG).show();
                }
            });
        }
        base.addView(top);

        FrameLayout playerHolder = new FrameLayout(this);
        base.addView(playerHolder,new LinearLayout.LayoutParams(-1,0,1));
        if (videoUri != null && !videoUri.isEmpty()) {
            localPlayer = new VideoView(this);
            playerHolder.addView(localPlayer,new FrameLayout.LayoutParams(-1,-1));
            MediaController controls = new MediaController(this);
            controls.setAnchorView(localPlayer);
            localPlayer.setMediaController(controls);
            localPlayer.setOnPreparedListener(mp -> { mp.setLooping(false); localPlayer.start(); });
            localPlayer.setOnErrorListener((mp,what,extra)->{
                Toast.makeText(this,"تعذر تشغيل الفيديو. ربما تم نقله أو حذفه من الهاتف.",Toast.LENGTH_LONG).show();
                return true;
            });
            try { localPlayer.setVideoURI(Uri.parse(videoUri)); localPlayer.requestFocus(); }
            catch (Exception e) { Toast.makeText(this,"تعذر فتح ملف الفيديو",Toast.LENGTH_LONG).show(); }
        } else if (videoUrl != null && videoUrl.startsWith("https://")) {
            browser = new WebView(this);
            browser.setBackgroundColor(Color.BLACK);
            browser.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            WebSettings settings=browser.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(true);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(browser,true);
            browser.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                    Uri uri=request.getUrl();
                    String scheme=uri.getScheme();
                    if ("https".equalsIgnoreCase(scheme)) return false;
                    if ("http".equalsIgnoreCase(scheme)) return true;
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
                    catch (Exception ignored) { Toast.makeText(PlayerActivity.this,"رابط غير مدعوم",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
            });
            browser.setWebChromeClient(new WebChromeClient() {
                @Override public void onShowCustomView(View view,CustomViewCallback callback) {
                    if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
                    fullScreenView=view;
                    customCallback=callback;
                    root.addView(view,new FrameLayout.LayoutParams(-1,-1));
                    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                }
                @Override public void onHideCustomView() { exitFullScreen(); }
            });
            playerHolder.addView(browser,new FrameLayout.LayoutParams(-1,-1));
            browser.loadUrl(videoUrl);
        } else {
            TextView invalid=Ui.text(this,"رابط الفيديو غير صالح",18,Ui.MUTED,false);
            invalid.setGravity(Gravity.CENTER);
            playerHolder.addView(invalid);
        }
        TextView help=Ui.text(this,"قد تمنع بعض منصات الفيديو التشغيل داخل التطبيق؛ عندها استخدم «فتح خارجي».",12,Ui.MUTED,false);
        Ui.pad(help,this,20,17);
        base.addView(help);
        setContentView(root);
    }

    private void exitFullScreen() {
        if (fullScreenView == null) return;
        root.removeView(fullScreenView);
        fullScreenView=null;
        if (customCallback != null) { customCallback.onCustomViewHidden(); customCallback=null; }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override public void onBackPressed() {
        if (fullScreenView != null) { exitFullScreen(); return; }
        if (browser != null && browser.canGoBack()) { browser.goBack(); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        if (browser != null) browser.onPause();
        if (localPlayer != null) localPlayer.pause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (browser != null) browser.onResume();
    }
    @Override protected void onDestroy() {
        exitFullScreen();
        if (browser != null) { browser.stopLoading(); browser.destroy(); browser=null; }
        if (localPlayer != null) localPlayer.stopPlayback();
        super.onDestroy();
    }
}
