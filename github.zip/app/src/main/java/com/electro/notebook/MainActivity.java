package com.electro.notebook;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private LinearLayout list;
    private TextView totalText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.setup(this);
        LinearLayout root = Ui.column(this);
        root.setBackgroundColor(Ui.BG);
        ScrollView scroll = Ui.scroll(this);
        root.addView(scroll);
        LinearLayout content = Ui.column(this);
        Ui.pad(content, this, 22, 28);
        scroll.addView(content);

        TextView top = Ui.text(this, "⚡  دَفْتَرُ الكَهْرَبَاء", 14, Ui.ACCENT, true);
        content.addView(top, Ui.lp(this, -1, -2, 0, 20));
        content.addView(Ui.text(this, "مساحتك للعلم\nوالمعرفة.", 32, Ui.TEXT, true), Ui.lp(this,-1,-2,0,10));
        content.addView(Ui.text(this, "اجمع ملاحظاتك وصورك وفيديوهاتك في مكان واحد، وارجع إليها في أي وقت.", 15, Ui.MUTED, false), Ui.lp(this,-1,-2,0,25));

        LinearLayout summary = Ui.row(this);
        summary.setBackground(Ui.outline(Ui.CARD, Ui.BORDER, 20, this));
        Ui.pad(summary, this, 17, 18);
        LinearLayout labels = Ui.column(this);
        labels.addView(Ui.text(this,"مكتبتك العلمية",18,Ui.TEXT,true));
        labels.addView(Ui.text(this,"5 مجالات للدراسة والبحث",13,Ui.MUTED,false),Ui.lp(this,-1,-2,4,0));
        summary.addView(labels, Ui.weight(this));
        totalText = Ui.text(this, "0 ملاحظة", 14, Ui.ACCENT, true);
        totalText.setGravity(Gravity.CENTER);
        summary.addView(totalText);
        content.addView(summary, Ui.lp(this,-1,-2,0,28));

        content.addView(Ui.text(this,"اختر مجالًا",21,Ui.TEXT,true),Ui.lp(this,-1,-2,0,5));
        content.addView(Ui.text(this,"اضغط على أي قسم لعرض محتوياته",13,Ui.MUTED,false),Ui.lp(this,-1,-2,0,14));
        list = Ui.column(this);
        content.addView(list);
        content.addView(Ui.text(this,"بياناتك وملاحظاتك تُحفظ على جهازك. مشاهدة روابط الفيديو تحتاج إلى الإنترنت.",12,Ui.MUTED,false), Ui.lp(this,-1,-2,18,15));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (list == null) return;
        list.removeAllViews();
        try (Database db = new Database(this)) {
            int total = 0;
            for (int i = 0; i < Topics.NAMES.length; i++) {
                int count = db.count(i);
                total += count;
                addTopic(i,count);
            }
            totalText.setText(total + " ملاحظة");
        }
    }

    private void addTopic(int index, int count) {
        LinearLayout card = Ui.row(this);
        card.setBackground(Ui.outline(Ui.CARD, Ui.BORDER, 20, this));
        Ui.pad(card, this, 15, 18);
        TextView symbol = Ui.text(this, Topics.SYMBOLS[index], 24, Ui.BG, true);
        symbol.setGravity(Gravity.CENTER);
        symbol.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        symbol.setBackground(Ui.shape(Topics.COLORS[index],16,this));
        card.addView(symbol, Ui.lp(this,62,62,0,0));

        LinearLayout mid = Ui.column(this);
        mid.setPadding(Ui.dp(this,13),0,Ui.dp(this,13),0);
        mid.addView(Ui.text(this,Topics.NAMES[index],19,Ui.TEXT,true));
        mid.addView(Ui.text(this,Topics.DESCRIPTIONS[index],12,Ui.MUTED,false), Ui.lp(this,-1,-2,3,5));
        mid.addView(Ui.text(this,count + " ملاحظة محفوظة",12,Topics.COLORS[index],true));
        card.addView(mid,Ui.weight(this));
        TextView arrow = Ui.text(this,"‹",29,Ui.MUTED,false);
        card.addView(arrow);
        card.setOnClickListener(v -> {
            Intent intent = new Intent(this, CategoryActivity.class);
            intent.putExtra("topic", index);
            startActivity(intent);
        });
        list.addView(card, Ui.lp(this,-1,-2,0,11));
    }
}
