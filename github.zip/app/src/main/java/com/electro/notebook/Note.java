package com.electro.notebook;

final class Note {
    long id;
    int topic;
    String title = "";
    String body = "";
    String imagePath = "";
    String videoUrl = "";
    String videoUri = "";
    long updatedAt;

    boolean hasImage() { return imagePath != null && !imagePath.isEmpty(); }
    boolean hasVideo() { return (videoUrl != null && !videoUrl.isEmpty()) || (videoUri != null && !videoUri.isEmpty()); }
    boolean hasText() { return body != null && !body.trim().isEmpty(); }
}
