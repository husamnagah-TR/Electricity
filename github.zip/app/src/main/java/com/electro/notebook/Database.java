package com.electro.notebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

final class Database extends SQLiteOpenHelper {
    private static final String DB_NAME = "electric_notes.db";

    Database(Context c) { super(c, DB_NAME, null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, topic INTEGER NOT NULL, " +
                "title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', image_path TEXT NOT NULL DEFAULT '', " +
                "video_url TEXT NOT NULL DEFAULT '', video_uri TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_notes_topic ON notes(topic, updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    long save(Note note) {
        ContentValues values = new ContentValues();
        values.put("topic", note.topic);
        values.put("title", note.title);
        values.put("body", note.body);
        values.put("image_path", note.imagePath);
        values.put("video_url", note.videoUrl);
        values.put("video_uri", note.videoUri);
        values.put("updated_at", System.currentTimeMillis());
        SQLiteDatabase db = getWritableDatabase();
        if (note.id > 0) {
            int modified = db.update("notes", values, "id=?", new String[]{String.valueOf(note.id)});
            return modified > 0 ? note.id : -1;
        }
        return db.insert("notes", null, values);
    }

    Note get(long id) {
        try (Cursor cursor = getReadableDatabase().query("notes", null, "id=?", new String[]{String.valueOf(id)}, null, null, null)) {
            if (cursor.moveToFirst()) return from(cursor);
        }
        return null;
    }

    List<Note> list(int topic) {
        List<Note> notes = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("notes", null, "topic=?", new String[]{String.valueOf(topic)}, null, null, "updated_at DESC")) {
            while (cursor.moveToNext()) notes.add(from(cursor));
        }
        return notes;
    }

    int count(int topic) {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM notes WHERE topic=?", new String[]{String.valueOf(topic)})) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    void delete(long id) {
        getWritableDatabase().delete("notes", "id=?", new String[]{String.valueOf(id)});
    }

    private Note from(Cursor c) {
        Note n = new Note();
        n.id = c.getLong(c.getColumnIndexOrThrow("id"));
        n.topic = c.getInt(c.getColumnIndexOrThrow("topic"));
        n.title = c.getString(c.getColumnIndexOrThrow("title"));
        n.body = c.getString(c.getColumnIndexOrThrow("body"));
        n.imagePath = c.getString(c.getColumnIndexOrThrow("image_path"));
        n.videoUrl = c.getString(c.getColumnIndexOrThrow("video_url"));
        n.videoUri = c.getString(c.getColumnIndexOrThrow("video_uri"));
        n.updatedAt = c.getLong(c.getColumnIndexOrThrow("updated_at"));
        return n;
    }
}
