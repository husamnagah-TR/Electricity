package com.electro.notebook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class CategoryActivity extends Activity {
    private int topic;
    private int filter = 0;
    private EditText search;
    private LinearLayout notesContainer;
    private TextView countLabel;
    private final TextView[] filters = new TextView[4];
    private static final String[] NAMES = {"الكل", "نصوص", "صور", "فيديو"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.setup(this);
        topic = Topics.safeIndex(getIntent().getIntExtra("topic", 0));
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Ui.BG);
        LinearLayout outer = Ui.column(this);
        frame.addView(outer, new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll = Ui.scroll(this);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content = Ui.column(this);
        Ui.pad(content,this,20,22);
        scroll.addView(content);
        content.addView(Ui.back(this),Ui.lp(this,-2,-2,0,24));
        TextView label = Ui.text(this,Topics.SYMBOLS[topic] + "  /  ملاحظاتي",14,Topics.COLORS[topic],true);
        content.addView(label,Ui.lp(this,-1,-2,0,8));
        content.addView(Ui.text(this,Topics.NAMES[topic],30,Ui.TEXT,true));
        content.addView(Ui.text(this,Topics.DESCRIPTIONS[topic],14,Ui.MUTED,false),Ui.lp(this,-1,-2,5,25));

        search = Ui.input(this,"ابحث في ملاحظات هذا القسم...",false);
        search.setSingleLine(true);
        content.addView(search,Ui.lp(this,-1,-2,0,15));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count) { reload(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        LinearLayout tabs = Ui.row(this);
        for (int i=0;i<NAMES.length;i++) {
            final int f = i;
            filters[i] = Ui.pill(this,NAMES[i],Ui.MUTED);
            LinearLayout.LayoutParams tabParams = new LinearLayout.LayoutParams(0,Ui.dp(this,43),1);
            tabParams.leftMargin = Ui.dp(this,5);
            tabs.addView(filters[i],tabParams);
            filters[i].setOnClickListener(v -> { filter = f; highlightFilters(); reload(); });
        }
        content.addView(tabs,Ui.lp(this,-1,-2,0,21));
        countLabel = Ui.text(this,"",15,Ui.MUTED,true);
        content.addView(countLabel,Ui.lp(this,-1,-2,0,14));
        notesContainer = Ui.column(this);
        content.addView(notesContainer, Ui.lp(this,-1,-2,0,90));

        TextView add = Ui.text(this,"＋  إضافة معلومة جديدة",17,Ui.BG,true);
        add.setGravity(Gravity.CENTER);
        add.setBackground(Ui.shape(Ui.ACCENT,17,this));
        add.setElevation(Ui.dp(this,10));
        FrameLayout.LayoutParams action = new FrameLayout.LayoutParams(-1,Ui.dp(this,58),Gravity.BOTTOM);
        action.setMargins(Ui.dp(this,20),0,Ui.dp(this,20),Ui.dp(this,17));
        frame.addView(add,action);
        add.setOnClickListener(v -> {
            Intent intent = new Intent(this,EditorActivity.class);
            intent.putExtra("topic",topic);
            startActivity(intent);
        });
        setContentView(frame);
        highlightFilters();
    }

    @Override protected void onResume() { super.onResume(); if (notesContainer != null) reload(); }

    private void highlightFilters() {
        for (int i=0;i<filters.length;i++) {
            filters[i].setBackground(Ui.shape(i == filter ? Ui.ACCENT : Ui.CARD_LIGHT,14,this));
            filters[i].setTextColor(i == filter ? Ui.BG : Ui.MUTED);
        }
    }

    private void reload() {
        if (notesContainer == null || countLabel == null) return;
        notesContainer.removeAllViews();
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        try (Database db = new Database(this)) {
            List<Note> list = db.list(topic);
            for (Note n : list) {
                boolean kind = filter == 0 || (filter == 1 && n.hasText()) ||
                        (filter == 2 && n.hasImage()) || (filter == 3 && n.hasVideo());
                if (!kind) continue;
                if (!q.isEmpty() && !(n.title+" "+n.body).toLowerCase(Locale.ROOT).contains(q)) continue;
                addNote(n);
                shown++;
            }
        }
        countLabel.setText(shown + " من الملاحظات");
        if (shown == 0) {
            LinearLayout empty = Ui.column(this);
            empty.setGravity(Gravity.CENTER);
            empty.setBackground(Ui.outline(Ui.CARD,Ui.BORDER,20,this));
            Ui.pad(empty,this,24,40);
            TextView icon = Ui.text(this,"✧",48,Ui.ACCENT,true);
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon);
            TextView msg = Ui.text(this,q.isEmpty() && filter == 0 ? "لا توجد ملاحظات بعد" : "لا توجد نتائج مطابقة",20,Ui.TEXT,true);
            msg.setGravity(Gravity.CENTER);
            empty.addView(msg,Ui.lp(this,-1,-2,4,10));
            TextView hint = Ui.text(this,"أضف نصوصك أو صورك أو روابط الفيديو، وستظهر هنا.",14,Ui.MUTED,false);
            hint.setGravity(Gravity.CENTER);
            empty.addView(hint);
            notesContainer.addView(empty,Ui.lp(this,-1,-2,0,0));
        }
    }

    private void addNote(Note note) {
        LinearLayout card = Ui.column(this);
        card.setBackground(Ui.outline(Ui.CARD,Ui.BORDER,17,this));
        Ui.pad(card,this,17,17);
        LinearLayout head = Ui.row(this);
        head.addView(Ui.text(this,note.title,18,Ui.TEXT,true),Ui.weight(this));
        TextView arrow = Ui.text(this,"‹",26,Ui.ACCENT,false);
        head.addView(arrow);
        card.addView(head);
        if (note.hasText()) {
            TextView body = Ui.text(this,note.body,14,Ui.MUTED,false);
            body.setMaxLines(3);
            body.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.addView(body,Ui.lp(this,-1,-2,7,12));
        }
        LinearLayout tags = Ui.row(this);
        if (note.hasText()) tags.addView(tag("▤  نص"));
        if (note.hasImage()) tags.addView(tag("▧  صورة"));
        if (note.hasVideo()) tags.addView(tag("▷  فيديو"));
        card.addView(tags,Ui.lp(this,-1,-2,8,9));
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        card.addView(Ui.text(this,"آخر تعديل: "+dateFormat.format(new Date(note.updatedAt)),12,Ui.MUTED,false));
        card.setOnClickListener(v -> {
            Intent intent = new Intent(this,DetailActivity.class);
            intent.putExtra("id",note.id);
            startActivity(intent);
        });
        notesContainer.addView(card,Ui.lp(this,-1,-2,0,11));
    }

    private TextView tag(String label) {
        TextView tag = Ui.text(this,label,12,Ui.ACCENT,false);
        tag.setPadding(Ui.dp(this,9),Ui.dp(this,5),Ui.dp(this,9),Ui.dp(this,5));
        tag.setBackground(Ui.shape(Ui.CARD_LIGHT,8,this));
        LinearLayout.LayoutParams p = Ui.lp(this,-2,-2,0,0);
        p.leftMargin = Ui.dp(this,6);
        tag.setLayoutParams(p);
        return tag;
    }
}
