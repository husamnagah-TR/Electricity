package com.electro.notebook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;

public final class EditorActivity extends Activity {
    private static final int PICK_IMAGE = 701;
    private static final int PICK_VIDEO = 702;
    private Note note;
    private EditText titleInput, textInput, urlInput;
    private ImageView imagePreview;
    private TextView imageStatus, videoStatus;
    private Uri incomingImage;
    private String chosenImagePath = "";
    private String chosenVideoUri = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.setup(this);
        long noteId = getIntent().getLongExtra("id", 0);
        if (noteId > 0) {
            try (Database db = new Database(this)) { note = db.get(noteId); }
        }
        if (note == null) {
            note = new Note();
            note.topic = Topics.safeIndex(getIntent().getIntExtra("topic",0));
        }
        chosenImagePath = note.imagePath;
        chosenVideoUri = note.videoUri;

        LinearLayout outer = Ui.column(this);
        outer.setBackgroundColor(Ui.BG);
        ScrollView scroll = Ui.scroll(this);
        outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout form = Ui.column(this);
        Ui.pad(form,this,21,22);
        scroll.addView(form);

        form.addView(Ui.back(this),Ui.lp(this,-2,-2,0,21));
        form.addView(Ui.text(this,Topics.NAMES[note.topic],14,Topics.COLORS[note.topic],true));
        form.addView(Ui.text(this,note.id == 0 ? "معلومة جديدة" : "تعديل المعلومة",29,Ui.TEXT,true),Ui.lp(this,-1,-2,7,7));
        form.addView(Ui.text(this,"يمكنك جمع النص والصورة والفيديو في نفس الملاحظة.",14,Ui.MUTED,false),Ui.lp(this,-1,-2,0,25));

        form.addView(fieldLabel("عنوان الملاحظة"),Ui.lp(this,-1,-2,0,9));
        titleInput = Ui.input(this,"مثال: قانون أوم أو تجربة عملية",false);
        titleInput.setText(note.title);
        form.addView(titleInput,Ui.lp(this,-1,-2,0,22));

        form.addView(fieldLabel("النص والمعلومات"),Ui.lp(this,-1,-2,0,9));
        textInput = Ui.input(this,"اكتب ما تريد تذكره، مثل القوانين أو الشرح أو خطوات التجربة...",true);
        textInput.setText(note.body);
        form.addView(textInput,Ui.lp(this,-1,-2,0,22));

        form.addView(fieldLabel("إرفاق صورة (اختياري)"),Ui.lp(this,-1,-2,0,9));
        TextView pickImage = Ui.pill(this,"▧  اختيار صورة من الهاتف",Ui.ACCENT);
        form.addView(pickImage,Ui.lp(this,-1,-2,0,9));
        pickImage.setOnClickListener(v -> browse("image/*",PICK_IMAGE));
        imageStatus = Ui.text(this,"",13,Ui.MUTED,false);
        form.addView(imageStatus,Ui.lp(this,-1,-2,0,8));
        imagePreview = new ImageView(this);
        imagePreview.setBackground(Ui.shape(Ui.CARD,12,this));
        imagePreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        form.addView(imagePreview,Ui.lp(this,-1,165,0,8));
        TextView removeImage = Ui.pill(this,"إزالة الصورة",0xFFFF9E9C);
        form.addView(removeImage,Ui.lp(this,-2,-2,0,21));
        removeImage.setOnClickListener(v -> {
            incomingImage = null;
            chosenImagePath = "";
            refreshImage();
        });
        refreshImage();

        form.addView(fieldLabel("رابط الفيديو (اختياري)"),Ui.lp(this,-1,-2,0,9));
        urlInput = Ui.input(this,"https://www.youtube.com/watch?v=...",false);
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setText(note.videoUrl);
        form.addView(urlInput,Ui.lp(this,-1,-2,0,8));
        form.addView(Ui.text(this,"يمكن استخدام رابط يوتيوب أو أي صفحة فيديو. يحتاج التشغيل إلى الإنترنت.",12,Ui.MUTED,false),Ui.lp(this,-1,-2,0,23));

        form.addView(fieldLabel("أو إرفاق فيديو من الهاتف (اختياري)"),Ui.lp(this,-1,-2,0,9));
        TextView pickVideo = Ui.pill(this,"▷  اختيار ملف فيديو",Ui.ACCENT);
        form.addView(pickVideo,Ui.lp(this,-1,-2,0,8));
        pickVideo.setOnClickListener(v -> browse("video/*",PICK_VIDEO));
        videoStatus = Ui.text(this,"",13,Ui.MUTED,false);
        form.addView(videoStatus,Ui.lp(this,-1,-2,0,8));
        TextView removeVideo = Ui.pill(this,"إزالة ملف الفيديو",0xFFFF9E9C);
        form.addView(removeVideo,Ui.lp(this,-2,-2,0,25));
        removeVideo.setOnClickListener(v -> { chosenVideoUri=""; refreshVideo(); });
        refreshVideo();

        TextView save = Ui.text(this,"✓  حفظ المعلومة",18,Ui.BG,true);
        save.setGravity(Gravity.CENTER);
        save.setBackground(Ui.shape(Ui.ACCENT,15,this));
        save.setOnClickListener(v -> save());
        LinearLayout.LayoutParams saveParams=Ui.lp(this,-1,57,9,15);
        saveParams.leftMargin=Ui.dp(this,20);
        saveParams.rightMargin=Ui.dp(this,20);
        outer.addView(save,saveParams);
        setContentView(outer);
    }

    private TextView fieldLabel(String value) { return Ui.text(this,value,15,Ui.TEXT,true); }

    private void browse(String mimeType,int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mimeType);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,requestCode);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_IMAGE) {
            incomingImage = uri;
            refreshImage();
        } else if (requestCode == PICK_VIDEO) {
            try {
                getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                chosenVideoUri=uri.toString();
                refreshVideo();
            } catch (SecurityException e) {
                Toast.makeText(this,"تعذر الاحتفاظ بصلاحية هذا الفيديو، اختر ملفًا آخر.",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void refreshImage() {
        if (imagePreview == null) return;
        imagePreview.setImageDrawable(null);
        if (incomingImage != null) {
            imageStatus.setText("صورة جديدة جاهزة للحفظ");
            imagePreview.setVisibility(View.VISIBLE);
            try { imagePreview.setImageURI(incomingImage); } catch (Exception ignored) {}
        } else if (chosenImagePath != null && !chosenImagePath.isEmpty()) {
            imageStatus.setText("صورة محفوظة في هذه الملاحظة");
            imagePreview.setVisibility(View.VISIBLE);
            Media.display(imagePreview,chosenImagePath,850);
        } else {
            imageStatus.setText("لم تتم إضافة صورة");
            imagePreview.setVisibility(View.GONE);
        }
    }

    private void refreshVideo() {
        videoStatus.setText(chosenVideoUri == null || chosenVideoUri.isEmpty() ?
                "لم تتم إضافة ملف فيديو" : "تم اختيار ملف فيديو من الهاتف");
    }

    private void save() {
        String title = titleInput.getText().toString().trim();
        String body = textInput.getText().toString().trim();
        String url = urlInput.getText().toString().trim();
        if (!url.isEmpty() && !url.startsWith("https://")) {
            if (url.startsWith("http://")) {
                Toast.makeText(this,"استخدم رابط فيديو آمن يبدأ بـ https://",Toast.LENGTH_LONG).show();
                return;
            }
            url = "https://" + url;
        }
        if (!url.isEmpty()) {
            Uri parsed = Uri.parse(url);
            if (parsed.getHost() == null || parsed.getHost().isEmpty()) {
                Toast.makeText(this,"رجاء إدخال رابط فيديو صحيح",Toast.LENGTH_LONG).show();
                return;
            }
        }
        if (title.isEmpty() && body.isEmpty() && incomingImage == null &&
                (chosenImagePath == null || chosenImagePath.isEmpty()) && url.isEmpty() &&
                (chosenVideoUri == null || chosenVideoUri.isEmpty())) {
            Toast.makeText(this,"أضف نصًا أو صورة أو فيديو أولًا",Toast.LENGTH_LONG).show();
            return;
        }
        if (title.isEmpty()) title = !body.isEmpty() ? body.substring(0,Math.min(50,body.length())) : "معلومة بدون عنوان";
        String originalPath = note.imagePath;
        String savedNewPath = "";
        if (incomingImage != null) {
            try {
                savedNewPath = Media.saveImage(this,incomingImage);
                chosenImagePath = savedNewPath;
            } catch (IOException e) {
                Toast.makeText(this,"تعذر حفظ الصورة: " + e.getMessage(),Toast.LENGTH_LONG).show();
                return;
            }
        }
        note.title = title;
        note.body = body;
        note.videoUrl = url;
        note.videoUri = chosenVideoUri == null ? "" : chosenVideoUri;
        note.imagePath = chosenImagePath == null ? "" : chosenImagePath;
        long id;
        try (Database db = new Database(this)) {
            id=db.save(note);
        } catch (Exception e) {
            id=-1;
        }
        if (id < 0) {
            Media.removeStoredImage(this,savedNewPath);
            Toast.makeText(this,"تعذر حفظ الملاحظة",Toast.LENGTH_LONG).show();
            return;
        }
        if (originalPath != null && !originalPath.equals(note.imagePath)) Media.removeStoredImage(this,originalPath);
        Toast.makeText(this,"تم حفظ المعلومة",Toast.LENGTH_SHORT).show();
        finish();
    }
}
